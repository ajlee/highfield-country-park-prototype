$(document).ready(function(){
    $("a").tooltip();
});
